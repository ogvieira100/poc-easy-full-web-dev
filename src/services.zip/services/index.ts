/**
 * Camada de acesso aos serviços .NET Core API.
 *
 * Estrutura:
 * - api/          — cliente HTTP tipado, envelope e contratos compartilhados.
 * - customers/    — serviço e DTOs do controller Customers (uma pasta por API).
 *
 * Uso:
 *   import { customersApi, ApiError } from '../services';
 */
export * from './api';
export * from './customers';
