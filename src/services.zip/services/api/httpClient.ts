import type { ApiEnvelope, ProblemDetails } from './types';

/**
 * URL base da API .NET Core.
 * Configurável por ambiente via VITE_API_BASE_URL (ver .env.development).
 * O padrão segue o launchSettings.json do serviço (perfil http).
 */
const BASE_URL = (import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:5031').replace(/\/+$/, '');

/**
 * Erro tipado da camada de API: carrega o status HTTP e o ProblemDetails
 * retornado pelos handlers de exceção da Util.
 */
export class ApiError extends Error {
    /** Status HTTP (0 quando a conexão com o servidor falhou). */
    readonly status: number;
    /** ProblemDetails da API, quando disponível. */
    readonly problemDetails: ProblemDetails | null;

    constructor(message: string, status: number, problemDetails: ProblemDetails | null = null) {
        super(message);
        this.name = 'ApiError';
        this.status = status;
        this.problemDetails = problemDetails;
    }
}

function isProblemDetails(body: unknown): body is ProblemDetails {
    return typeof body === 'object' && body !== null && 'title' in body && 'type' in body;
}

function isEnvelope<T>(body: unknown): body is ApiEnvelope<T> {
    return typeof body === 'object' && body !== null && 'success' in body && 'data' in body;
}

function buildUrl(path: string, params?: object): string {
    const url = `${BASE_URL}/${path.replace(/^\/+/, '')}`;
    if (!params) {
        return url;
    }
    const search = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
        if (value !== undefined && value !== null) {
            search.set(key, String(value));
        }
    }
    const query = search.toString();
    return query ? `${url}?${query}` : url;
}

function jsonInit(method: string, body?: unknown): RequestInit {
    return {
        method,
        headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
        body: body !== undefined ? JSON.stringify(body) : undefined,
    };
}

async function request<T>(url: string, init?: RequestInit): Promise<T> {
    let response: Response;
    try {
        response = await fetch(url, init);
    } catch {
        throw new ApiError('Falha de conexão com o servidor.', 0);
    }

    let body: unknown = null;
    const text = await response.text();
    if (text) {
        try {
            body = JSON.parse(text);
        } catch {
            // Corpo não-JSON: mantém body nulo.
        }
    }

    // Handlers de exceção da Util respondem ProblemDetails (RFC 7807).
    if (isProblemDetails(body)) {
        throw new ApiError(body.detail ?? body.title ?? 'Erro retornado pela API.', response.status, body);
    }

    if (!response.ok) {
        throw new ApiError(`Erro ${response.status} ao chamar a API.`, response.status);
    }

    // Sucesso: desempacota o envelope { success, data } do BaseController.
    if (isEnvelope<T>(body)) {
        if (!body.success) {
            throw new ApiError('A API reportou falha na requisição.', response.status);
        }
        return body.data;
    }

    return body as T;
}

/**
 * Cliente HTTP tipado: desempacota o envelope da API e converte erros
 * em ApiError com o ProblemDetails original.
 */
export const httpClient = {
    get<T>(path: string, params?: object): Promise<T> {
        return request<T>(buildUrl(path, params));
    },
    post<T>(path: string, body?: unknown): Promise<T> {
        return request<T>(buildUrl(path), jsonInit('POST', body));
    },
    put<T>(path: string, body?: unknown): Promise<T> {
        return request<T>(buildUrl(path), jsonInit('PUT', body));
    },
    delete<T>(path: string, body?: unknown): Promise<T> {
        return request<T>(buildUrl(path), jsonInit('DELETE', body));
    },
};
